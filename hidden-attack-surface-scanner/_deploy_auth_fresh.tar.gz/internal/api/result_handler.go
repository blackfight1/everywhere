package api

import (
	"context"
	"net/http"
	"strings"
	"time"

	appconfig "hidden-attack-surface-scanner/internal/config"
	"hidden-attack-surface-scanner/internal/database"
	"hidden-attack-surface-scanner/pkg/notify"

	"github.com/gin-gonic/gin"
)

func (s *Server) listPingbacks(c *gin.Context) {
	query := s.db.Order("received_at desc")

	if severity := c.Query("severity"); severity != "" {
		query = query.Where("severity = ?", severity)
	}
	if protocol := c.Query("protocol"); protocol != "" {
		query = query.Where("callback_protocol = ?", protocol)
	}
	if taskID := c.Query("scan_task_id"); taskID != "" {
		query = query.Where("scan_task_id = ?", taskID)
	}

	rows, err := s.buildPingbackEvidence(query)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, rows)
}

func (s *Server) getPingback(c *gin.Context) {
	rows, err := s.buildPingbackEvidence(s.db.Where("id = ?", c.Param("id")).Limit(1))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if len(rows) == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "pingback not found"})
		return
	}
	c.JSON(http.StatusOK, rows[0])
}

func (s *Server) getStats(c *gin.Context) {
	var scanCount, activeCount, pingbackCount int64
	s.db.Model(&database.ScanTask{}).Count(&scanCount)
	s.db.Model(&database.ScanTask{}).Where("status IN ?", []string{"running", "waiting_callback"}).Count(&activeCount)
	s.db.Model(&database.Pingback{}).Count(&pingbackCount)

	var recent []database.Pingback
	s.db.Order("received_at desc").Limit(10).Find(&recent)

	c.JSON(http.StatusOK, gin.H{
		"scan_count":     scanCount,
		"active_count":   activeCount,
		"pingback_count": pingbackCount,
		"recent":         recent,
	})
}

func (s *Server) getSettings(c *gin.Context) {
	c.JSON(http.StatusOK, s.cfg)
}

func (s *Server) updateSettings(c *gin.Context) {
	var input appconfig.Config
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	s.cfg.Interactsh = input.Interactsh
	if input.Scanner.DefaultConcurrency > 0 {
		s.cfg.Scanner = input.Scanner
	}
	if input.OwnIP.Action != "" {
		s.cfg.OwnIP.Action = input.OwnIP.Action
	}
	s.cfg.Notification = input.Notification

	c.JSON(http.StatusOK, s.cfg)
}

type testNotificationRequest struct {
	Enabled         bool   `json:"enabled"`
	FeishuWebhook   string `json:"feishu_webhook"`
	FrontendBaseURL string `json:"frontend_base_url"`
}

func (s *Server) testNotification(c *gin.Context) {
	var input testNotificationRequest
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	webhook := strings.TrimSpace(input.FeishuWebhook)
	if webhook == "" {
		webhook = strings.TrimSpace(s.cfg.Notification.FeishuWebhook)
	}
	if webhook == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "feishu webhook is empty"})
		return
	}

	baseURL := strings.TrimSpace(input.FrontendBaseURL)
	if baseURL == "" {
		baseURL = strings.TrimSpace(s.cfg.Notification.FrontendBaseURL)
	}

	alert := notify.BuildTestAlert(baseURL)
	ctx, cancel := context.WithTimeout(c.Request.Context(), 12*time.Second)
	defer cancel()

	response, err := notify.SendFeishuCard(ctx, webhook, alert)
	if err != nil {
		c.JSON(http.StatusBadGateway, gin.H{"error": err.Error(), "response": response})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"status":       "sent",
		"response":     response,
		"preview_text": alert.Title,
	})
}
